const mysql = require('mysql');
const exp = require('express');
const cors = require('cors');
const app = exp();
const path = require('path')
const bodyParser = require('body-parser'); 
const port = 3000;
 
const urlencodedParser = bodyParser.urlencoded({ extended: false })  
app.use(
    cors({
        origin: "*"
    })
)
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "art_news"

});

let info ="SELECT * FROM block ";

var tt = '';


function databaseConnection() {
    if(con.state === "disconnected"){
      con.connect(function(err) {
          if (err) throw err;
          console.log("Connected!");
        });
    }
    return con;
}
// con.query(sqlquery, function (err, result) {
//   if (err) throw err;
//   tt = result;
//   console.log(tt);

  
// });
const query1 = "SELECT COUNT(*) FROM block";
databaseConnection().query(info,function(err,result){
  if(err ) throw err;
  tt = result ;
});
app.get('/data', (req, res) => {
  
   console.log(tt)
    res.json(tt)
    
   
  });
  app.use('/', exp.static('public'))
  app.post('/process', urlencodedParser, function (req, res) {  
    
    response = {  
        
        first_name:req.body.first_name,  
        last_name:req.body.last_name  
    };  


    let info2 =`INSERT INTO block (Title,Text,Link_img,In_menu) VALUES(${databaseConnection().escape(response.first_name)},${databaseConnection().escape(response.last_name)},NULL, 0 )`;
    console.log(info2); 
    databaseConnection().query(info2);
    console.log(response);  
    
    res.redirect("/");  
 })  
  app.listen(3000, () => {
    console.log("Server running on port 3000");
   });
