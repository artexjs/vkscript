

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "art_news"
  
  });
// db.js

const mysql = require('mysql');

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "art_news"
});

module.export = {
  getConnection: (callback) => {
    return pool.getConnection(callback);
  } 
}


